/*
Q40: Write a program to find the 1’s complement of a binary number and print it.

Sample Test Cases:
Input 1:
1010
Output 1:
0101

Input 2:
1111
Output 2:
0000

*/

#include <stdio.h>

int main() {
    char bin[64];
    int i;
    scanf("%63s", bin);
    for (i = 0; bin[i] != '\0'; i++)
        printf("%c", bin[i] == '0' ? '1' : '0');
    printf("\n");
    return 0;
}
